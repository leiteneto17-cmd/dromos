# Padrões de Engenharia — [Nome do Projeto]

> Gerado por engineering-standards. Convenções já declaradas no projeto têm prioridade sobre os defaults da skill. Complexity Mode identificado: **[Pequeno / Médio / Enterprise]**.

## Nomenclatura
- **Declarado**: [convenções encontradas em CLAUDE.md/README/lint config/código existente]
- **Default aplicado**: [o que a skill preencheu por lacuna]

## Estrutura de Pastas
- **Declarado**: [estrutura real do projeto]
- **Default aplicado**: [preenchimento por lacuna, se houver]
- Nota: decisões de arquitetura de domínio pertencem ao software-architect quando existirem; aqui é só convenção técnica de organização.

## Padrão de Commits
- **Declarado**: [tipos/convenção em uso no histórico de commits, incluindo tipos customizados do projeto]
- **Default aplicado**: [Conventional Commits, se nada foi declarado]

## Definition of Done
- **Declarado**: [fluxo real do time/projeto]
- **Baseline default**: revisado, testado, documentado, sem regressão, implantável

## Política de Testes
- **Declarado**: [o que já existe]
- **Default aplicado, calibrado ao Complexity Mode**: [proporcional ao porte]
- **Dívida técnica consciente** (se houver): [ex: "teste manual por ora, automação disparada por gatilho X"]

## Documentação
- **Declarado**: [...]
- **Default aplicado**: [...]

## Tratamento de Erros
- **Declarado**: [...]
- **Default aplicado**: [...]

## Logging
- **Declarado**: [...]
- **Default aplicado**: [...]

## Versionamento
- **Declarado**: [...]
- **Default aplicado**: [...]

## Princípios Arquiteturais Gerais
- **Declarado**: [...]
- **Default aplicado**: [...]

## Regras Específicas do Projeto
[Decisões de negócio/domínio descobertas durante a análise que não são "padrão geral de engenharia", mas são regras já em vigor - ex: "cache obrigatório de custo de IA/TTS", "RLS em toda tabela nova". Documente aqui mesmo que não se encaixem nas categorias acima.]

---
**Local de persistência**: `docs/PADROES-ENGENHARIA.md` (ou caminho/nome já em uso no projeto). Atualize este documento sempre que uma nova convenção for declarada explicitamente pelo time - ele é a fonte de verdade viva, não uma foto única.
